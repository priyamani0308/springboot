import {Route, Routes} from 'react-router-dom'
import './App.css'
import UserContextProvider from './context/UserContextProvider'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Protector from './components/Protector'

function App() {

  return (
    <UserContextProvider>
      <Routes>
        <Route path='login' element={<Login/>}/>
        <Route index element={<Protector element={<Dashboard/>}/>} />
      </Routes>
    </UserContextProvider>
  )
}

export default App
