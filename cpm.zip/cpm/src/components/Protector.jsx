import React, {useContext} from 'react'
import {UserContext} from '../context/UserContextProvider'
import {useNavigate} from 'react-router-dom'

const Protector = ({element}) => {
    const [user] = useContext(UserContext)
    const navigate = useNavigate()
    if(user !== "admin") navigate("/login")
  return <>{element}</>;
}

export default Protector
