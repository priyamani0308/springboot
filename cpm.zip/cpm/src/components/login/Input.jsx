import React from 'react'

const Input = ({name, type, input, setInput}) => {
  return (
    <div className="flex flex-col justify-center w-2/3">
      <label className="text-slate-400 pb-2">{name}</label>
      <input
        className="h-12 rounded-lg shadow-sm ps-2"
        type={type}
        value={input}
        onChange={(e) => {
          setInput(e.target.value);
        }}
      />
    </div>
  );
}

export default Input
