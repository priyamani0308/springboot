import React, {useEffect, useState} from 'react'
import axios from "../../axios/index.js"
import CustomerRow from './CustomerRow.jsx'

const CustomerTable = () => {
    const [customers, setCustomers] = useState([])
    const getCustomers = ()=>{
        axios.get("customers/getallcustomer").then((res)=>setCustomers(res.data));
    }
    useEffect(()=>{
        getCustomers();
    },[])
    console.log(customers)
  return (
    <div>
      <div className="flex justify-between items-center bg-blue-200 px-1 py-2 mt-2 font-bold text-blue-900 text-center">
        <span className="w-1/6">Id</span>
        <span className="w-1/6">Name</span>
        <span className="w-1/6"> Email</span>
        <span className="w-1/6">Address</span>
        <span className="w-1/6">Delete</span>
      </div>
      {customers.length!==0 && customers.map((customer, index)=>(<CustomerRow key={index} index={index} customer={customer}/>))}
    </div>
  );
}

export default CustomerTable
