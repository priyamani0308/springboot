import React from 'react'

const Input = ({name}) => {
  return (
      <div className='flex flex-col gap-2 w-1/4'>
        <label>{name}</label>
        <input type="text" placeholder={name} className='placeholder:text-sm bg-white shadow-md p-2 rounded'/>
      </div>
  );
}

export default Input
