import React from 'react'
import axios from "../../axios/index.js";

const CustomerRow = ({customer, index}) => {
    const deleteCustomer = ()=>{
        axios
          .delete("customers/deletecustomerbyid/"+customer.customerId)
    }
    console.log("key", index)
  return (
    <div className={`flex justify-between items-center px-1 py-2 text-black ${index % 2 !== 0 && 'bg-slate-100'}`}>
      <span className="w-1/6">{customer.customerId}</span>
      <span className="w-1/6">{customer.customerName}</span>
      <span className="w-1/6">{customer.email}</span>
      <span className="w-1/6">{customer.address}</span>
      <button className="bg-red-500 rounded shadow px-2 py-2 text-white flex items-center justify-center gap-4" onClick={()=>deleteCustomer()}>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M13 7a4 4 0 11-8 0 4 4 0 018 0zM9 14a6 6 0 00-6 6v1h12v-1a6 6 0 00-6-6zM21 12h-6"
          />
        </svg>
        <span>Delete</span>
      </button>
    </div>
  );
}

export default CustomerRow
