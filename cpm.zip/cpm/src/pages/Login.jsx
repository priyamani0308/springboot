import React, {useContext, useState} from 'react'
import Input from '../components/login/Input'
import lottie from "../assets/lottie.json"
import Lottie from "react-lottie";
import {UserContext} from '../context/UserContextProvider';
import {useNavigate} from 'react-router-dom';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [,setUser] = useContext(UserContext)
    const navigate = useNavigate();
    const defaultOptions = {
      loop: true,
      autoplay: true,
      animationData: lottie,
      rendererSettings: { preserveAspectRatio: "xMidYMid slice" },
    };
    const validateInput = (e)=>{
      e.preventDefault()
      if(username === "admin" && password === "admin") {
        setUser("Admin")
        navigate("/")
        console.log("logged")
      }
    }
  return (
    <div className="flex flex-row ">
      <div className="w-1/2 bg-blue-500 flex flex-col justify-center items-center">
        <Lottie options={defaultOptions} height={300} className="w-full"/>
      </div>
      <form onSubmit={(e)=>validateInput(e)} className="w-1/2 bg-slate-100 h-screen flex flex-col justify-center items-center gap-10">
        <h1 className="text-4xl font-bold">Login</h1>
        <Input
          type="text"
          name="Username"
          input={username}
          setInput={setUsername}
        />
        <Input
          type="Password"
          name="Password"
          input={password}
          setInput={setPassword}
        />
        <button className="bg-gradient-to-r to-blue-400 from-blue-500 w-2/3 h-12 rounded-lg shadow-lg text-white text-lg font-mono">
          Login
        </button>
      </form>
    </div>
  );
}

export default Login
