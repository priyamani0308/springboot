import React from 'react'
import Navbar from '../components/Navbar'
import InputRow from '../components/dashboard/InputRow'
import CustomerTable from '../components/dashboard/CustomerTable'

const Dashboard = () => {
  return (
    <div>
        <Navbar/>
        <InputRow/>
        <CustomerTable/>
    </div>
  )
}

export default Dashboard
